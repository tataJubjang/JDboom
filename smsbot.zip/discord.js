const { Client, Intents, MessageEmbed } = require('discord.js');

const { exec } = require('child_process');



const talkedRecently = new Set();

const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES, Intents.FLAGS.DIRECT_MESSAGES] });

const tokendiscord = "";

var Allow_Channel = [
	"930408299713683526",
]

const perfix = "!vs"

function validate(phonee) {
  const regex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
  return regex.test(phonee)
}


function validate(phone) {
  const regex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
  return regex.test(phone)
}

client.once('ready', () => {
  console.log(`

▓█████▄  ██▓  ██████  ▄████▄   ▒█████   ██▀███  ▓█████▄ 
▒██▀ ██▌▓██▒▒██    ▒ ▒██▀ ▀█  ▒██▒  ██▒▓██ ▒ ██▒▒██▀ ██▌
░██   █▌▒██▒░ ▓██▄   ▒▓█    ▄ ▒██░  ██▒▓██ ░▄█ ▒░██   █▌
░▓█▄   ▌░██░  ▒   ██▒▒▓▓▄ ▄██▒▒██   ██░▒██▀▀█▄  ░▓█▄   ▌
░▒████▓ ░██░▒██████▒▒▒ ▓███▀ ░░ ████▓▒░░██▓ ▒██▒░▒████▓ 
 ▒▒▓  ▒ ░▓  ▒ ▒▓▒ ▒ ░░ ░▒ ▒  ░░ ▒░▒░▒░ ░ ▒▓ ░▒▓░ ▒▒▓  ▒ 
 ░ ▒  ▒  ▒ ░░ ░▒  ░ ░  ░  ▒     ░ ▒ ▒░   ░▒ ░ ▒░ ░ ▒  ▒ 
 ░ ░  ░  ▒ ░░  ░  ░  ░        ░ ░ ░ ▒    ░░   ░  ░ ░  ░ 
   ░     ░        ░  ░ ░          ░ ░     ░        ░    
 ░                   ░                           ░      

`)
  console.log(`Logged in as ${client.user.username}#${client.user.discriminator}!`);
});



client.on("messageCreate", msg => {
  if (Allow_Channel.includes(msg.channelId)) {
    var msgs = msg.content.split(' ');
    if (msgs[0] == perfix+'mk') {
      if (talkedRecently.has(msg.author.id)) {
        const embederror = new MessageEmbed()
          .setColor('#0xE74C3C')
          .setTitle('RATE LIMIT')
          .setDescription('รอ120วิค่ะ')
		  .setImage("https://media.discordapp.net/attachments/905106957822754876/915603753279815711/Clock.gif");
        msg.reply({ embeds: [embederror] })
      } else {
        var phonee = msgs[1];
        var count = msgs[2];
        if (validate(phonee) && phonee.length == 10 && count > 0 && count <= 1000) {
          const embedsend = new MessageEmbed()
            .setColor('#0099ff')
	        .setTitle('SPM HI SPEED')
	        .setURL('https://discord.js.org/')
	        .setAuthor('FB', 'https://i.imgur.com/wSTFkRM.png', 'https://discord.js.org')
	        .setDescription(`กำลังยิงไปที่เบอร์ ${msgs[1]}\n จำนวน ${count * 1}/1000 ครั้ง\n สามารถโดเนทค่าไฟได้ที่ Waĺletหรือธนาคารได้เลย`)
	        .setThumbnail('https://i.imgur.com/wSTFkRM.png')
	        .addField('SCK', 'lnwhee')
	        .setImage('https://i.imgur.com/wSTFkRM.png')
	         .setTimestamp()
	        .setFooter('SCK', 'https://i.imgur.com/wSTFkRM.png');
	      talkedRecently.add(msg.author.id);
	      setTimeout(() => {
            talkedRecently.delete(msg.author.id);
          }, 120000);//เวลาการลบข้อความ
          msg.reply({ embeds: [embedsend] })
          var execstr = `node sm.js ${phonee} ${count}`
          exec(execstr)
        } else {
          const embederror = new MessageEmbed()
            .setColor('#0xE74C3C')
            .setTitle('ERROR')
            .setDescription(perfix+'mk [เบอร์] [จำนวน 0-1000] นะคะ');
          msg.reply({ embeds: [embederror] })
        }
      }
    }else{
    }
  }
});

client.on("messageCreate", msg => {
  if (Allow_Channel.includes(msg.channelId)) {
    var msgs = msg.content.split(' ');
    if (msgs[0] == perfix+'sms') {
      if (talkedRecently.has(msg.author.id)) {
        const embederror = new MessageEmbed()
          .setColor('#0xE74C3C')
          .setTitle('RATE LIMIT')
          .setDescription('รอ120วิค่ะ')
		  .setImage("https://media.discordapp.net/attachments/905106957822754876/915603753279815711/Clock.gif");
        msg.reply({ embeds: [embederror] })
      } else {
        var phone = msgs[1];
        var count = msgs[2];
        if (validate(phone) && phone.length == 10 && count > 0 && count <= 1000) {
          const embedsend = new MessageEmbed()
            .setColor('#0099ff')
	        .setTitle('SPM HI SPEED')
	        .setURL('https://discord.js.org/')
	        .setAuthor('FB', 'https://i.imgur.com/wSTFkRM.png', 'https://discord.js.org')
	        .setDescription(`กำลังยิงไปที่เบอร์ ${msgs[1]}\n จำนวน ${count * 1}/1000 ครั้ง\n สามารถโดเนทค่าไฟได้ที่ Waĺletหรือธนาคารได้เลย`)
	        .setThumbnail('https://i.imgur.com/wSTFkRM.png')
	        .addField('SCK', 'lnwhee')
	        .setImage('https://i.imgur.com/wSTFkRM.png')
	         .setTimestamp()
	        .setFooter('SCK', 'https://i.imgur.com/wSTFkRM.png');
          talkedRecently.add(msg.author.id);
          setTimeout(() => {
            talkedRecently.delete(msg.author.id);
          }, 120000);//เวลาการลบข้อความ
          msg.reply({ embeds: [embedsend] })
          var execstr = `node sms.js ${phone} ${count}`
          exec(execstr)
        } else {
          const embederror = new MessageEmbed()
            .setColor('#0xE74C3C')
            .setTitle('ERROR')
            .setDescription(perfix+'sms [เบอร์] [จำนวน 0-1000] นะคะ');
          msg.reply({ embeds: [embederror] })
        }
      }
    }else{
    }
  }
});

client.login(tokendiscord);
